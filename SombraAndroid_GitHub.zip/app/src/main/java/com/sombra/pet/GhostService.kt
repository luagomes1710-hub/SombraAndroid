package com.sombra.pet

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.*
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.FrameLayout
import kotlin.math.min

class GhostService : Service() {
    private lateinit var wm: WindowManager
    private var ghost: GhostView? = null
    private var params: WindowManager.LayoutParams? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        params = WindowManager.LayoutParams(
            dp(104), dp(120), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(18); y = dp(180)
        }
        ghost = GhostView().also { view ->
            view.setOnTouchListener(object : View.OnTouchListener {
                var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
                var dragged = false
                override fun onTouch(v: View, e: MotionEvent): Boolean {
                    val p = params ?: return false
                    when (e.action) {
                        MotionEvent.ACTION_DOWN -> {
                            downX = e.rawX; downY = e.rawY; startX = p.x; startY = p.y; dragged = false
                            return true
                        }
                        MotionEvent.ACTION_MOVE -> {
                            val dx = (e.rawX - downX).toInt(); val dy = (e.rawY - downY).toInt()
                            if (kotlin.math.abs(dx) + kotlin.math.abs(dy) > dp(5)) dragged = true
                            p.x = startX + dx; p.y = startY + dy
                            try { wm.updateViewLayout(v, p) } catch (_: Exception) {}
                            return true
                        }
                        MotionEvent.ACTION_UP -> {
                            if (!dragged) {
                                val i = Intent(this@GhostService, ChatActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                startActivity(i)
                            }
                            return true
                        }
                    }
                    return false
                }
            })
            wm.addView(view, params)
        }
    }
    private fun startAsForeground() {
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(
            NotificationChannel("sombra", "Sombra", NotificationManager.IMPORTANCE_LOW)
        )
        val notification = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, "sombra").setContentTitle("Sombra está por perto")
                .setContentText("Toque no fantasma para conversar. Use o app para desligá-lo.")
                .setSmallIcon(android.R.drawable.ic_menu_view).build()
        else @Suppress("DEPRECATION") Notification.Builder(this)
            .setContentTitle("Sombra está por perto").setSmallIcon(android.R.drawable.ic_menu_view).build()
        startForeground(7, notification)
    }
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    override fun onDestroy() {
        ghost?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        ghost = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null

    private inner class GhostView : View(this@GhostService) {
        private val fill = Paint(3)
        private val glow = Paint(3)
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val s = min(width / 104f, height / 120f)
            canvas.save()
            canvas.scale(s, s)
            // Violet wisps behind the body
            fill.color = Color.rgb(93, 37, 157)
            canvas.drawOval(9f, 16f, 95f, 105f, fill)
            fill.color = Color.rgb(23, 15, 34)
            val path = Path().apply {
                moveTo(52f, 7f)
                cubicTo(23f, 5f, 11f, 29f, 15f, 56f)
                cubicTo(17f, 76f, 6f, 88f, 12f, 101f)
                cubicTo(22f, 93f, 27f, 106f, 37f, 99f)
                cubicTo(47f, 113f, 55f, 98f, 64f, 103f)
                cubicTo(77f, 112f, 85f, 94f, 94f, 101f)
                cubicTo(101f, 79f, 90f, 70f, 91f, 48f)
                cubicTo(92f, 24f, 77f, 8f, 52f, 7f)
                close()
            }
            canvas.drawPath(path, fill)
            // Purple rim
            glow.color = Color.rgb(143, 65, 230); glow.style = Paint.Style.STROKE; glow.strokeWidth = 2.4f
            canvas.drawPath(path, glow)
            glow.style = Paint.Style.FILL
            glow.color = Color.rgb(255, 20, 58)
            canvas.drawOval(29f, 42f, 45f, 57f, glow)
            canvas.drawOval(60f, 42f, 76f, 57f, glow)
            fill.color = Color.BLACK
            canvas.drawOval(34f, 45f, 40f, 53f, fill)
            canvas.drawOval(65f, 45f, 71f, 53f, fill)
            fill.color = Color.rgb(228, 178, 255)
            canvas.drawCircle(37f, 46f, 2f, fill); canvas.drawCircle(68f, 46f, 2f, fill)
            fill.color = Color.rgb(10, 5, 16)
            val grin = Path().apply { moveTo(35f, 66f); quadTo(53f, 84f, 72f, 64f); quadTo(54f, 73f, 35f, 66f); close() }
            canvas.drawPath(grin, fill)
            fill.color = Color.rgb(207, 163, 255)
            canvas.drawText("...", 42f, 92f, Paint(3).apply { color = Color.rgb(207,163,255); textSize = 12f; typeface = Typeface.DEFAULT_BOLD })
            canvas.restore()
        }
    }
}
