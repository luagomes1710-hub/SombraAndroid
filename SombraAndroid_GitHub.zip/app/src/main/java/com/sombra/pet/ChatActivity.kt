package com.sombra.pet

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import android.text.InputType

class ChatActivity : Activity() {
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(18), dp(18), dp(18))
            setBackgroundColor(Color.rgb(15, 10, 25))
        }
        root.addView(TextView(this).apply {
            text = "👁️  Sombra"; textSize = 27f; setTextColor(Color.rgb(210,170,255))
        })
        val conversation = TextView(this).apply {
            text = "Sombra: Finalmente! Achei que você tinha sido abduzido.\n\nSombra: Manda uma pergunta, humano. Prometo responder com dignidade... talvez."
            textSize = 17f; setTextColor(Color.WHITE); setPadding(0, dp(20), 0, dp(20))
        }
        root.addView(conversation, LinearLayout.LayoutParams(-1, 0, 1f))
        val input = EditText(this).apply {
            hint = "Fale com o Sombra..."; setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        root.addView(input)
        root.addView(Button(this).apply {
            text = "Enviar"
            setOnClickListener {
                val q = input.text.toString().trim()
                if (q.isNotEmpty()) {
                    val answer = when {
                        q.contains("origem", true) || q.contains("história", true) ->
                            "Minha origem? Nasci de uma sombra que ficou tempo demais sozinha num quarto... então aprendi a assustar o tédio. E talvez algumas pessoas. 😈"
                        q.contains("quem é você", true) || q.contains("seu nome", true) ->
                            "Sou o Sombra: fantasma, especialista em pegadinhas e inocente em 97% dos casos."
                        q.contains("oi", true) || q.contains("olá", true) ->
                            "Opa, humano! Já senti cheiro de oportunidade para uma pegadinha."
                        q.contains("piada", true) || q.contains("engraçado", true) ->
                            "Por que fantasma não mente? Porque dá pra ver através dele. ...Eu odeio admitir que ri disso."
                        else -> "Boa pergunta: '$q'. Ainda estou aprendendo a responder qualquer coisa. Minha mente de fantasma está no modo protótipo! 👻"
                    }
                    conversation.text = "Você: $q\n\nSombra: $answer"
                    input.text.clear()
                }
            }
        })
        setContentView(root)
    }
}
