package com.sombra.pet

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
            setBackgroundColor(Color.rgb(15, 10, 25))
        }
        root.addView(TextView(this).apply {
            text = "👁️  SOMBRA"
            textSize = 32f
            setTextColor(Color.rgb(210, 170, 255))
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "Seu fantasma particular. Ative-o para deixá-lo flutuar sobre os outros aplicativos.\n\nEste é o primeiro protótipo: a conversa ainda usa respostas locais, sem IA conectada."
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, dp(24))
        })
        root.addView(Button(this).apply {
            text = "LIGAR O SOMBRA"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else {
                    startForegroundService(Intent(this@MainActivity, GhostService::class.java))
                }
            }
        }, LinearLayout.LayoutParams(-1, dp(56)))
        root.addView(Button(this).apply {
            text = "DESLIGAR O SOMBRA"
            setOnClickListener { stopService(Intent(this@MainActivity, GhostService::class.java)) }
        }, LinearLayout.LayoutParams(-1, dp(56)))
        root.addView(Button(this).apply {
            text = "CONVERSAR"
            setOnClickListener { startActivity(Intent(this@MainActivity, ChatActivity::class.java)) }
        }, LinearLayout.LayoutParams(-1, dp(56)))
        setContentView(root)
    }
}
