# Sombra para Android (protótipo 0.1)

Este projeto é o começo de um mascote flutuante para Android, com um fantasma preto/roxo e olhos vermelhos.

## O que já está implementado
- App com controles para ligar e desligar o mascote.
- Solicitação da permissão Android para aparecer sobre outros apps.
- Serviço em primeiro plano enquanto o mascote está ativo.
- Fantasma desenhado por código, arrastável e tocável.
- Tela de conversa com respostas locais de demonstração, incluindo uma origem inicial.

## Limites atuais
- Não há IA conectada: as respostas são regras locais e limitadas.
- Não há memória persistente de conversas ainda.
- O app não está assinado nem compilado em APK nesta entrega.
- Android pode exigir autorização de notificações e de sobreposição, conforme a versão e as configurações do aparelho.

## Como abrir
1. Instale o Android Studio em um computador.
2. Abra a pasta `SombraAndroid` no Android Studio.
3. Deixe o Gradle sincronizar e compile/execute em um Android físico.
4. Abra o app e toque em **LIGAR O SOMBRA**; conceda a permissão de aparecer sobre outros apps.
5. Volte ao app e ligue o Sombra. Use **DESLIGAR O SOMBRA** para removê-lo.

## Próxima etapa
Conectar uma API de IA com chave protegida por um backend, adicionar memória, configurações de personalidade, animações e controles melhores. Não coloque uma chave de API secreta diretamente no app.
